﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROGPOE_FinalSubmission
{

    public class DeweyNode 
    { 
        public string CallNumber { get; }
        public string Description { get;  }
        public List<DeweyNode> Dewey { get; }

        public DeweyNode( string callNumber, string description)
        {
            CallNumber = callNumber;
            Description = description;
            Dewey = new List<DeweyNode>();
        }
    }

    public partial class MatchColumns : Form
    {
        private int currentScore = 0;
        private bool isMatchingDescription = true;

        /*
        private List<string> callNumbers = new List<string> { "001", "002", "003", "004" };
        private List<string> descriptions = new List<string> { "Description A", "Description B", "Description C", "Description D" };
        */
        private Dictionary<string, string> callNumberDescriptionDictionary = new Dictionary<string, string>();+
      
        //----------------------------------------------------------------------------------------------------------------//

        //----------------------------------------------------------------------------------------------------------------------------//
        public MatchColumns()
        {
            InitializeComponent();
            LoadDeweyTree(); // Call the method to load the dewey decimal data into the tree
            DisplayNewQuestion();

            
        }
        private void LoadDeweyTree()
        {
            List<string> dataFromFile = new List<string>
            { 
            "300; Arts and Recreation",
            "350; Painting",
            "351;Techniques, procedures forms",
            "352; Pyschology"
            };

            root = BuildDeweyTree(DataFromFile);
            
        }

        private DeweyNode BuildDeweyTree(List<string> data)
        {
            var nodesByCallNumber = new Dictionary<string, DeweyNode>();

            foreach (var line in data)
            {
                var parts = line.Split(';');
                if (parts.Length == 2)
                {
                    string callNumber = parts[0].Trim();
                    string description = parts[1].Trim();
                    var newNode = DeweyNode(callNumber, description);
                    nodesByCallNumber[callNumber] = newNode;

                    if (callNumber.Contains('.'))
                    {
                        var parentsCallNumber = callNumber.Substring(0, callNumber.LastIndexOf('.'));
                        nodesByCallNumber[parentsCallNumber]Dewey.Add(newNode);
                    }
                }
            }
            //Return the root node, which is the one without the parent
            return nodesByCallNumber.Values.FirstOrDefault(node => !node.CallNumber.Contains('.'));
        }
        //-------------------------------------------------------//

        //------------------------------------------------------//


        private void DisplayNewQuestion()
        {
            lblCallNum.Text = "";
            lblDescrip.Text = "";
            txtCallNumAnswer.Text = "";
            txtDescripAnswer.Text = "";

            var randomIndex = new Random().Next(callNumberDescriptionDictionary.Count);
            var selectedPair = callNumberDescriptionDictionary.ElementAt(randomIndex);

            /*
            //Randomly select call number and description for the question
            int randomIndex = new Random().Next(callNumbers.Count);
            string selectCallNum = callNumbers[randomIndex];
            string selectDescrip = descriptions[randomIndex];
            */


            //Displays the question
            if (isMatchingDescription)
            {
                lblCallNum.Text = selectedPair.Key; //Call Numebr
                lblDescrip.Text = "Match the call numbers to the descriptions";
            }
            else
            {
                lblDescrip.Text = selectedPair.Value; //Description
                lblCallNum.Text = "Match this call number to the desciption: ";
            }
        }
        //-------------------------------------------------------------------//

        //------------------------------------------------------------------//
        private void lblCallNum_Click(object sender, EventArgs e)
        {

        }
        //---------------------------------------------------------------//

        //----------------------------------------------------------------//
        private void btnNewQues_Click(object sender, EventArgs e)
        {
            DisplayNewQuestion();
        }
        //---------------------------------------------------------------//

        //----------------------------------------------------------------//
        private void btnSubAnswer_Click(object sender, EventArgs e)
        {
            CheckAndScoreAnswer();
        }
        //--------------------------------------------------------------//

        //--------------------------------------------------------------//
        private void CheckAndScoreAnswer()
        {

            string userAnswer = isMatchingDescription ? txtDescripAnswer.Text : txtCallNumAnswer.Text;

            string correctAnswer = isMatchingDescription ? callNumberDescriptionDictionary[lblCallNum.Text] : callNumberDescriptionDictionary.FirstOrDefault(x => x.Value == lblDescrip.Text).Key;
            //string correctAnswer = isMatchingDescription ? callNumbers.First(c => c == lblDescrip.Text) : descriptions.First(d => d == lblCallNum.Text);

            if (userAnswer == correctAnswer)
            {
                //Correct Answer
                currentScore += 10;
                lblScore.Text = $"Score: {currentScore}";
                MessageBox.Show("Correct!");
            }
            else
            {
                //Incorrect answer
                MessageBox.Show($"Incorrect! The correct answer is: {correctAnswer}");

            }
            isMatchingDescription = !isMatchingDescription;
            DisplayNewQuestion();
        }
        //--------------------------------------------------------------------//

        //------------------------------------------------------------------------//
        private void btnEndGame_Click(object sender, EventArgs e)
        {
            //Displays message box to show users final score
            MessageBox.Show($"Game Over! Your finals score is: {currentScore}", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information);

            currentScore = 0;
            lblScore.Text = "Score: 0";
            isMatchingDescription = true;
            DisplayNewQuestion(); // Display new question to reset the UI
        }
        //--------------------------------------------------------------//

        //-----------------------------------------------------------------//
        private void txtCallNumAnswer_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDescripAnswer_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblDescrip_Click(object sender, EventArgs e)
        {

        }

        private void lblScore_Click(object sender, EventArgs e)
        {

        }
        //-------------------------------------------------------------//

        //---------------------------------------------------------------//
        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //-------------------------------------------------------------------//

        //-----------------------------------------------------------------//
        private void btnBack_Click(object sender, EventArgs e)
        {
            //hide the current form (matchColumns)
            this.Hide();

            //Shows form1 if it not visible
            if(Application.OpenForms.OfType<Form1>().Count() == 0)
            {
                Form1 form1 = new Form1();
                form1.Show();
            }
            else
            {
                //If form1 is open bring to the front
                Application.OpenForms.OfType<Form1>().First().BringToFront();

            }
            
        }
        private void LoadDeweyDataFromFile(string filePath)
        {
            try
            {
                string[] lines = System.IO.File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] parts = line.Split(';');
                    if (parts.Length == 2)
                    {
                        string callNumber = parts[0].Trim();
                        string description = parts[1].Trim();
                        callNumberDescriptionDictionary.Add(callNumber, description);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading the Dewey Deciaml data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //New method to load Dewey Decimal data from file
        private Dictionary<string, string> LoadDeweyDataFromFile(string filePath)
        {
            Dictionary<string, string> deweyData = new Dictionary<string, string>();
       
            try
            {
                string[] DataGridLineStyle = FileDialog.ReadAllLines(filePath);

                foreach (string line in DataGridLineStyle)
                {
                    string[] parts = line.Split(';');
                    if (parts.Length == 2)
                    {
                        string callNumber = parts[0].Trim();
                        string description = parts[1].Trim();
                        deweyData.Add(callNumber, description);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading the dewey decimal data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return deweyData;
        }

        //New method to start finding call nhumbers task
        private void StartFindingCallNumbersTask()
        {
            string filePath = "C:\Users\User\source\repos\PROGPOE_FinalSubmission\PROGPOE_FinalSubmission";
            callNumberDescriptionDictionary = LoadDeweyDataFromFile(filePath);

            DisplayQuizQuestion();

        }

        private void DisplayQuizQuestion()
        {
            var random = new Random();
            var thirdLevelEntry = callNumberDescriptionDictionary.Where(entry => entry.Key.Count(C => C == '.') == 2).ElementAt(random.Next(callNumberDescriptionDictionary.Count)); //Filter third level entries

            string description = thirdLevelEntry.Value;

            //Display only the description
            MessageBox.Show($"Match the description: \n\n{description}", "Finding all call numbers", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Display four top level options
            List<string> options = GetRandomTopLevelOptions(thirdLevelEntry.Key);

            string selectedOption = DisplayOptions(options);

            //Check if selected option is correct
            if(selectedOption == thirdLevelEntry.Key.Split('.')[0])
            {
                DisplayNextLevelOptions(thirdLevelEntry.Key);
            }
            else
            {
                MessageBox.Show("Incorrect! Please try the next question.", "Incorrect Answer", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DisplayQuizQuestion();
            }
        }
        private List<string> GetRandomTopLevelOptions(string correctOption)
        {
            var random = new Random();
            var allOptions = callNumberDescriptionDictionary.Where(entry => entry.Key.Count(c => c == '.') == 1).Select(entry => entry.Key.Split('.')[0]).ToList();

            allOptions.Remove(correctOption.Split('.')[0]);

            var incorrectOptions = allOptions.OrderBy(_ => random.Next()).Take(3).ToList();

            incorrectOptions.Add(correctOption.Split('.')[0]);

            incorrectOptions = incorrectOptions.OrderBy(_ => random.Next()).ToList();

            return incorrectOptions;
        }

        private string DisplayOptions(List<string> options)
        {
            string selectOption = null;

            var buttons = new List<Button>();
            foreach ( string option in options)
            {
                Button button = new Button();
                button.Text = option;
                button.Click += (sender, e) => { selectedOption = ((Button)sender).Text; };
                buttons.Add(button);
            }

            for(int i = 0; i < buttons.Count; i++)
            {
                buttons[i].Location = new Point(50, 50 + i * 30);
                this.Controls.Add(buttons[i]);
            }

            while (selectedOption == null)
            {
                Application.DoEvents();
                Application.DoEvents();
                System.Threading.Thread.Sleep(10);
            }
            foreach (Button button in buttons)
            {
                this.Controls.Remove(button);
                button.Dispose();
            }
            return selectedOption;
        }

        private void DisplayNextLevelOptions(string currentOption)
        {
            var nextLevelOptions = callNumberDescriptionDictionary.Where(entry => entry.Key.StartsWith(currentOption)).Select(entry => entry.Key.Split('.')[1]).Distinct().ToList();

            List<string> options = GetRandomTopLevelOptions(nextLevelOptions);
            string selectedOption = DisplayOptions(options);

            if (selectedOption == currentOption.Split('.')[1])
            {
                MessageBox.Show("Correct! Moving on to the next level.", "Correct Answer", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("Incorrect! Please try the next question.","Incorrect Answer", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DisplayQuizQuestion();
            }
        }
    }
}
