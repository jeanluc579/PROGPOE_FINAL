﻿
namespace PROGPOE_FinalSubmission
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPoints = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.lstCallNumbers = new System.Windows.Forms.ListBox();
            this.btnRepBooks = new System.Windows.Forms.Button();
            this.btnSortBooks = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.txtCallNumbers = new System.Windows.Forms.TextBox();
            this.txtAuthorName = new System.Windows.Forms.TextBox();
            this.btnMoveUp = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnMatchColGame = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPoints
            // 
            this.lblPoints.AutoSize = true;
            this.lblPoints.Location = new System.Drawing.Point(73, 55);
            this.lblPoints.Name = "lblPoints";
            this.lblPoints.Size = new System.Drawing.Size(39, 13);
            this.lblPoints.TabIndex = 0;
            this.lblPoints.Text = "Points:";
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(261, 55);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(36, 13);
            this.lblTimer.TabIndex = 1;
            this.lblTimer.Text = "Timer:";
            // 
            // lstCallNumbers
            // 
            this.lstCallNumbers.FormattingEnabled = true;
            this.lstCallNumbers.Location = new System.Drawing.Point(76, 99);
            this.lstCallNumbers.Name = "lstCallNumbers";
            this.lstCallNumbers.Size = new System.Drawing.Size(242, 186);
            this.lstCallNumbers.TabIndex = 2;
            // 
            // btnRepBooks
            // 
            this.btnRepBooks.Location = new System.Drawing.Point(76, 312);
            this.btnRepBooks.Name = "btnRepBooks";
            this.btnRepBooks.Size = new System.Drawing.Size(91, 23);
            this.btnRepBooks.TabIndex = 3;
            this.btnRepBooks.Text = "Replace Books";
            this.btnRepBooks.UseVisualStyleBackColor = true;
            this.btnRepBooks.Click += new System.EventHandler(this.btnRepBooks_Click);
            // 
            // btnSortBooks
            // 
            this.btnSortBooks.Location = new System.Drawing.Point(222, 312);
            this.btnSortBooks.Name = "btnSortBooks";
            this.btnSortBooks.Size = new System.Drawing.Size(96, 23);
            this.btnSortBooks.TabIndex = 4;
            this.btnSortBooks.Text = "Sort Books";
            this.btnSortBooks.UseVisualStyleBackColor = true;
            this.btnSortBooks.Click += new System.EventHandler(this.btnSortBooks_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(147, 374);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(95, 23);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "EXIT GAME";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnAddItem
            // 
            this.btnAddItem.Location = new System.Drawing.Point(444, 99);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(75, 23);
            this.btnAddItem.TabIndex = 6;
            this.btnAddItem.Text = "Add Item";
            this.btnAddItem.UseVisualStyleBackColor = true;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(444, 170);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 7;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // txtCallNumbers
            // 
            this.txtCallNumbers.Location = new System.Drawing.Point(561, 99);
            this.txtCallNumbers.Name = "txtCallNumbers";
            this.txtCallNumbers.Size = new System.Drawing.Size(100, 20);
            this.txtCallNumbers.TabIndex = 8;
            // 
            // txtAuthorName
            // 
            this.txtAuthorName.Location = new System.Drawing.Point(561, 170);
            this.txtAuthorName.Name = "txtAuthorName";
            this.txtAuthorName.Size = new System.Drawing.Size(100, 20);
            this.txtAuthorName.TabIndex = 9;
            // 
            // btnMoveUp
            // 
            this.btnMoveUp.Location = new System.Drawing.Point(476, 239);
            this.btnMoveUp.Name = "btnMoveUp";
            this.btnMoveUp.Size = new System.Drawing.Size(75, 23);
            this.btnMoveUp.TabIndex = 10;
            this.btnMoveUp.Text = "Move Up";
            this.btnMoveUp.UseVisualStyleBackColor = true;
            this.btnMoveUp.Click += new System.EventHandler(this.btnMoveUp_Click);
            // 
            // btnDown
            // 
            this.btnDown.Location = new System.Drawing.Point(616, 239);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(75, 23);
            this.btnDown.TabIndex = 11;
            this.btnDown.Text = "Move Down";
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnMatchColGame
            // 
            this.btnMatchColGame.Location = new System.Drawing.Point(535, 336);
            this.btnMatchColGame.Name = "btnMatchColGame";
            this.btnMatchColGame.Size = new System.Drawing.Size(113, 77);
            this.btnMatchColGame.TabIndex = 12;
            this.btnMatchColGame.Text = "MATCH COLUMNS GAME";
            this.btnMatchColGame.UseVisualStyleBackColor = true;
            this.btnMatchColGame.Click += new System.EventHandler(this.btnMatchColGame_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMatchColGame);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnMoveUp);
            this.Controls.Add(this.txtAuthorName);
            this.Controls.Add(this.txtCallNumbers);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAddItem);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSortBooks);
            this.Controls.Add(this.btnRepBooks);
            this.Controls.Add(this.lstCallNumbers);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.lblPoints);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPoints;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.ListBox lstCallNumbers;
        private System.Windows.Forms.Button btnRepBooks;
        private System.Windows.Forms.Button btnSortBooks;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.TextBox txtCallNumbers;
        private System.Windows.Forms.TextBox txtAuthorName;
        private System.Windows.Forms.Button btnMoveUp;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnMatchColGame;
    }
}

