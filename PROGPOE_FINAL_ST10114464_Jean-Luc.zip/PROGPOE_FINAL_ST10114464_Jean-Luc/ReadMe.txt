Dewey Decimal SYstem Quiz Application
-------------------------------------

Overview
--------
This application is designed to enhance users udnerstanding of the Dewey Decimal System
--------

--------------------
Matching Columns Task
---------------------
Match the call numbers to descriptions to call numbers and vice versa.

--Instructions--
1.) Click on "Matching Columns" in the main menu.
2.) The program prsents questions, alternating between matching call numbers to descriptions and vice versa.
3.) Answer the questions by inputting your response in the provided text boxes.
4.) Click "submit Answer" to check correctness.
5.) The gamification system awards points for correct answers.
6.) Click "New Question for the next question or "End Game" to finish.

### Finding Call Numbers Task
- **Description:** Drill down into the Dewey Decimal system hierarchy until finding the correct answer.
- **Instructions:**
  1. Click on "Finding Call Numbers" in the main menu.
  2. The program loads Dewey Decimal classification data.
  3. The quiz starts, asking you to match descriptions to top-level categories.
  4. Choose the correct top-level category from the options.
  5. If correct, the program displays options for the next level.
  6. If incorrect, the program indicates the mistake and proceeds to the next question.
  7. The quiz ends after reaching the most detailed level.
  8. Gamification system awards points for correct answers.

------General Features---------
- **New Question Button:** Get a new question in the matching columns task.
- **Back Button:** Return to the main menu.
- **Quit Button:** Close the application.
----------------------------------------------------------------------------------------


-------------Gamification----------------
The application incorporates a gamification system to motivate users. Earn points for correct answers and try to achieve a high score. The scoring system adds an element of challenge and encourages continued engagement.
-----------------------------------------------

------How to Use---------------------------------------

-------Compilation----------------------
To compile the program, use a C# development environment such as Visual Studio or Visual Studio Code. Open the project and build the solution.

-------Running the Program--------
After compilation, run the program on a Windows environment. Navigate to the compiled executable or run it from your development environment.

------Acknowledgments-----------
This program is part of a programming assignment for educational purposes. Your feedback is valuable, and you are welcome to contribute to its improvement.